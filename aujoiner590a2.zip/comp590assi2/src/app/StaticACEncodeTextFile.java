package app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import ac.ArithmeticEncoder;
import io.OutputStreamBitSink;

public class StaticACEncodeTextFile {

	public static void main(String[] args) throws IOException {
		long startTime = System.nanoTime();

		String input_file_name = "data/out.dat";
		String output_file_name = "data/compressed.txt";

		int range_bit_width = 40;

		System.out.println("Encoding text file: " + input_file_name);
		System.out.println("Output file: " + output_file_name);
		System.out.println("Range Register Bit Width: " + range_bit_width);

		int num_symbols = (int) new File(input_file_name).length();
		num_symbols = 1228800;

		// Analyze file for frequency counts

		FileInputStream fis = new FileInputStream(input_file_name);

		int[] freq_counts = new int[256];

		int next_byte = fis.read();

		while (next_byte != -1) {
			freq_counts[next_byte]++;
			next_byte = fis.read();
		}
		fis.close();

		Integer[] freqs = new Integer[256];
		for (int i = 0; i < 256; i++) {
			freqs[i] = i;
		}

		// Create new model with analyzed frequency counts
		FreqCountIntegerSymbolModel model = new FreqCountIntegerSymbolModel(freqs, freq_counts);

		ArithmeticEncoder<Integer> encoder = new ArithmeticEncoder<Integer>(range_bit_width);

		FileOutputStream fos = new FileOutputStream(output_file_name);
		OutputStreamBitSink bit_sink = new OutputStreamBitSink(fos);

		// First 256 * 4 bytes are the frequency counts
		for (int i = 0; i < 256; i++) {
			bit_sink.write(freq_counts[i], 32);
			// System.out.println(freq_counts[i]);
		}

		// Next 4 bytes are the number of symbols encoded
		bit_sink.write(num_symbols, 32);

		// Next byte is the width of the range registers
		bit_sink.write(range_bit_width, 8);

		// Now encode the input
		fis = new FileInputStream(input_file_name);

		for (int i = 0; i < num_symbols; i++) {
			int next_symbol = fis.read();
			encoder.encode(next_symbol, model, bit_sink);
			// System.out.println(next_symbol);
		}
		fis.close();

		// Finish off by emitting the middle pattern
		// and padding to the next word

		encoder.emitMiddle(bit_sink);
		bit_sink.padToWord();
		fos.close();

		System.out.println("Done");

		long endTime = System.nanoTime();
		long totalTime = endTime - startTime;
		System.out.println(totalTime);
	}
}
